import React, { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Formik, Form, ErrorMessage } from "formik";
import type { FormikProps, FormikHelpers } from "formik";
import { useDispatch } from "react-redux";
import { Fn_FillListData, Fn_AddEditData, Fn_DisplayData } from "../../store/Functions";
import { API_WEB_URLS } from "../../constants/constAPI";
import { handleEnterToNextField } from "../../utils/formUtils";
import * as Yup from "yup";
import { Card, CardBody, CardFooter, Col, Container, FormGroup, Input, Label, Row } from "reactstrap";
import Breadcrumbs from "../../CommonElements/Breadcrumbs/Breadcrumbs";
import CardHeaderCommon from "../../CommonElements/CardHeaderCommon/CardHeaderCommon";
import { Btn } from "../../AbstractElements";

interface FormValues {
    BranchName: string;
    BranchCode: string;
    ReportingRegion: string;
    IFSCCode: string;
    BranchManagerName: string;
    BranchOpeningDate: string;
    CashLimit: string;
    OpeningCashBalance: string;
    BranchAddress: string;
    F_CityMaster: string;
    F_StateMaster: string;
    ContactNumber: string;
    Email: string;
    Status: string;
}

const initialValues: FormValues = {
    BranchName: "",
    BranchCode: "",
    ReportingRegion: "",
    IFSCCode: "",
    BranchManagerName: "",
    BranchOpeningDate: "",
    CashLimit: "",
    OpeningCashBalance: "0",
    BranchAddress: "",
    F_CityMaster: "",
    F_StateMaster: "",
    ContactNumber: "",
    Email: "",
    Status: "Active",
};

interface DropdownState {
    regions: Array<{ Id?: number; Name?: string }>;
    states: Array<{ Id?: number; Name?: string }>;
    cities: Array<{ Id?: number; Name?: string }>;
}

interface BOState {
    id: number;
    formData: Partial<FormValues> & {
        Name?: string;
        Code?: string;
        F_RegionalOffice?: number | string;
        ManagerName?: string;
        OpeningDate?: string;
        Address?: string;
        ContactNo?: string;
        IsActive?: boolean;
        Status?: string;
    };
    isProgress?: boolean;
    isEditingOpen?: boolean;
}

const BranchOfficeCreation = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const location = useLocation();
    const branchNameRef = useRef<HTMLInputElement | null>(null);

    const [boState, setBoState] = useState<BOState>({
        id: 0,
        formData: { ...initialValues },
        isProgress: false,
        isEditingOpen: true,
    });

    const [isMapped, setIsMapped] = useState(false);

    const [dropdowns, setDropdowns] = useState<DropdownState>({
        regions: [],
        states: [],
        cities: [],
    });

    const isEditMode = boState.id > 0;

    // Update: Correct API URL for regions according to what's mapped in RegionalOffice
    const REGION_API_URL = `${API_WEB_URLS.MASTER}/0/token/RegionalOffice/Id/0`;
    const STATE_API_URL = `${API_WEB_URLS.MASTER}/0/token/${API_WEB_URLS.StateMaster}/Id/0`;
    const CITY_API_URL = `${API_WEB_URLS.MASTER}/0/token/${API_WEB_URLS.CityMaster}/Id/0`;

    const API_URL_EDIT = `${API_WEB_URLS.MASTER}/0/token/BranchOfficeEdit/Id`;
    const API_URL_SAVE = `BranchOffice/0/token`;

    const validationSchema = useMemo(
        () =>
            Yup.object({
                BranchName: Yup.string().trim().required("Branch Name is required"),
                BranchCode: Yup.string().trim().required("Branch Code is required"),
                ReportingRegion: Yup.string().trim().required("Reporting Region is required"),
                IFSCCode: Yup.string().trim().required("IFSC Code is required"),
                BranchManagerName: Yup.string().trim().required("Branch Manager Name is required"),
                BranchOpeningDate: Yup.string().trim().required("Branch Opening Date is required"),
                CashLimit: Yup.number().required("Cash Limit is required").min(0, "Cannot be negative"),
                OpeningCashBalance: Yup.number().required("Opening Cash Balance is required").min(0, "Cannot be negative"),
                BranchAddress: Yup.string().trim().required("Branch Address is required"),
                F_CityMaster: Yup.string().trim().required("City is required"),
                F_StateMaster: Yup.string().trim().required("State is required"),
                ContactNumber: Yup.string().trim().required("Contact Number is required"),
                Email: Yup.string().trim().email("Invalid email format").required("Email is required"),
                Status: Yup.string().trim().required("Status is required"),
            }),
        []
    );

    useEffect(() => {
        branchNameRef.current?.focus();
    }, []);

    useEffect(() => {
        Fn_FillListData(dispatch, setDropdowns, "regions", REGION_API_URL)
            .catch((err) => console.error("Failed to fetch regions:", err));
        Fn_FillListData(dispatch, setDropdowns, "states", STATE_API_URL)
            .catch((err) => console.error("Failed to fetch states:", err));
        Fn_FillListData(dispatch, setDropdowns, "cities", CITY_API_URL)
            .catch((err) => console.error("Failed to fetch cities:", err));
    }, [dispatch, REGION_API_URL, STATE_API_URL, CITY_API_URL]);

    useEffect(() => {
        if (boState.id > 0 && Object.keys(boState.formData).length > 2 && !isMapped && boState.formData.F_StateMaster) {
            Fn_FillListData(
                dispatch,
                setDropdowns,
                "cities",
                `${API_WEB_URLS.MASTER}/0/token/${API_WEB_URLS.CityMaster}/Id/${boState.formData.F_StateMaster}`
            ).catch((err) => console.error("Failed to fetch cities by state on edit:", err));
            setIsMapped(true);
        }
    }, [boState.id, boState.formData, dispatch, isMapped]);

    useEffect(() => {
        const locationState = location.state as { Id?: number } | undefined;
        // Defaulting to 1 for dev debug, but ideally we check recordId correctly
        const recordId = (locationState?.Id && locationState.Id > 0) ? locationState.Id : 0;

        if (recordId > 0) {
            setBoState((prev) => ({
                ...prev,
                id: recordId,
                isEditingOpen: true, // Fixed: Enable editing when in edit mode
            }));
            Fn_DisplayData(dispatch, setBoState, recordId, API_URL_EDIT);
        } else {
            setBoState((prev) => ({
                ...prev,
                id: 0,
                formData: { ...initialValues },
                isEditingOpen: true,
            }));
            setIsMapped(false);
        }
    }, [dispatch, location.state, API_URL_EDIT]);

    const handleStateChange = (
        e: React.ChangeEvent<HTMLInputElement>,
        handleChange: FormikProps<FormValues>["handleChange"],
        setFieldValue: FormikProps<FormValues>["setFieldValue"]
    ) => {
        handleChange(e);
        const selectedState = e.target.value;
        if (selectedState) {
            Fn_FillListData(dispatch, setDropdowns, "cities", `${API_WEB_URLS.MASTER}/0/token/${API_WEB_URLS.CityMaster}/Id/${selectedState}`).catch((err) => {
                console.error("Failed to fetch cities by state:", err);
            });
        } else {
            setDropdowns((prev) => ({ ...prev, cities: [] }));
        }
        setFieldValue("F_CityMaster", "");
    };

    const toStringOrEmpty = (value: unknown) => (value !== undefined && value !== null ? String(value) : "");

    const initialFormValues: FormValues = {
        ...initialValues,
        BranchName: toStringOrEmpty(boState.formData.Name ?? boState.formData.BranchName),
        BranchCode: toStringOrEmpty(boState.formData.Code ?? boState.formData.BranchCode),
        ReportingRegion: toStringOrEmpty(boState.formData.F_RegionalOffice ?? boState.formData.ReportingRegion),
        IFSCCode: toStringOrEmpty(boState.formData.IFSCCode),
        BranchManagerName: toStringOrEmpty(boState.formData.ManagerName ?? boState.formData.BranchManagerName),
        BranchOpeningDate: toStringOrEmpty(boState.formData.OpeningDate ?? boState.formData.BranchOpeningDate).split("T")[0],
        CashLimit: toStringOrEmpty(boState.formData.CashLimit),
        OpeningCashBalance: toStringOrEmpty(boState.formData.OpeningCashBalance) || "0",
        BranchAddress: toStringOrEmpty(boState.formData.Address ?? boState.formData.BranchAddress),
        F_CityMaster: toStringOrEmpty(boState.formData.F_CityMaster),
        F_StateMaster: toStringOrEmpty(boState.formData.F_StateMaster),
        ContactNumber: toStringOrEmpty(boState.formData.ContactNo ?? boState.formData.ContactNumber),
        Email: toStringOrEmpty(boState.formData.Email),
        Status: boState.formData.IsActive === true || boState.formData.Status === "Active" ? "Active" :
            (boState.formData.IsActive === false || boState.formData.Status === "Inactive" ? "Inactive" : "Active"),
    };

    const handleSubmit = async (values: FormValues, { setSubmitting }: FormikHelpers<FormValues>) => {
        try {
            const formData = new FormData();

            formData.append("Id", String(boState.id ?? 0));
            formData.append("Name", values.BranchName || "");
            formData.append("Code", values.BranchCode || "");
            formData.append("F_RegionalOffice", values.ReportingRegion || "");
            formData.append("IFSCCode", values.IFSCCode || "");
            formData.append("ManagerName", values.BranchManagerName || "");
            formData.append("OpeningDate", values.BranchOpeningDate || "");
            formData.append("CashLimit", values.CashLimit || "0");
            formData.append("OpeningCashBalance", values.OpeningCashBalance || "0");
            formData.append("Address", values.BranchAddress || "");
            formData.append("F_CityMaster", values.F_CityMaster || "");
            formData.append("F_StateMaster", values.F_StateMaster || "");
            formData.append("ContactNo", values.ContactNumber || "");
            formData.append("Email", values.Email || "");
            formData.append("IsActive", values.Status === "Active" ? "true" : "false");

            const storedUser = localStorage.getItem("user");
            const currentUser = storedUser ? JSON.parse(storedUser) : null;
            const userId = currentUser?.uid ?? currentUser?.id ?? "0";
            formData.append("UserId", userId);
            formData.append("F_BranchOffice", localStorage.getItem("F_BranchOffice") || "");

            // Dynamically construct API save url based on image format: /api/V1/BranchOffice/{UserId}/{UserToken}
            const currentApiUrlSave = `BranchOffice/${userId}/token`;

            await Fn_AddEditData(
                dispatch,
                () => { }, // Placeholder callback
                { arguList: { id: boState.id, formData } },
                currentApiUrlSave,
                true,
                "memberid",
                navigate,
                "/branchOfficeCreation"
            );

        } catch (error) {
            console.error("Submission failed:", error);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="page-body">
            <Breadcrumbs mainTitle="Branch Office Creation" parent="Setup & Admin" />
            <Container fluid>
                <Row>
                    <Col xs="12">
                        <Formik<FormValues>
                            initialValues={initialFormValues}
                            validationSchema={validationSchema}
                            onSubmit={handleSubmit}
                            enableReinitialize
                        >
                            {({ values, handleChange, handleBlur, errors, touched, isSubmitting, setFieldValue }: FormikProps<FormValues>) => (
                                <Form className="theme-form" onKeyDown={handleEnterToNextField}>
                                    <Card>
                                        <CardHeaderCommon title={`${isEditMode ? "Edit" : "Add"} Branch Office`} tagClass="card-title mb-0" />
                                        <CardBody className="py-2">
                                            <fieldset disabled={!boState.isEditingOpen}>
                                                <Row className="g-2">
                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Branch Name <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="text"
                                                                name="BranchName"
                                                                placeholder="e.g. Andheri Branch"
                                                                value={values.BranchName}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.BranchName && !!errors.BranchName}
                                                                    innerRef={branchNameRef}
                                                            />
                                                            <ErrorMessage name="BranchName" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Branch Code <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="text"
                                                                name="BranchCode"
                                                                placeholder="Auto-generated: ABC-NZ01-BR001"
                                                                value={values.BranchCode}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.BranchCode && !!errors.BranchCode}
                                                            />
                                                            <ErrorMessage name="BranchCode" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Reporting Regional Office <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="select"
                                                                name="ReportingRegion"
                                                                value={values.ReportingRegion}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.ReportingRegion && !!errors.ReportingRegion}
                                                            >
                                                                <option value="">-- Select Region --</option>
                                                                {/* {dropdowns.regions.length === 0 && <option value="RO001">North Zone Office (RO001)</option>} */}
                                                                {dropdowns.regions.map((regionOption) => (
                                                                    <option key={regionOption?.Id} value={regionOption?.Id ?? ""}>
                                                                        {regionOption?.Name || `Region ${regionOption?.Id ?? ""}`}
                                                                    </option>
                                                                ))}
                                                            </Input>
                                                            <ErrorMessage name="ReportingRegion" component="div" className="text-danger small mt-1" />

                                                        </FormGroup>
                                                    </Col>
                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                IFSC Code <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="text"
                                                                name="IFSCCode"
                                                                placeholder="ABCD0001234"
                                                                value={values.IFSCCode}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.IFSCCode && !!errors.IFSCCode}
                                                            />
                                                            <ErrorMessage name="IFSCCode" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Branch Manager Name <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="text"
                                                                name="BranchManagerName"
                                                                placeholder="Enter manager name"
                                                                value={values.BranchManagerName}



                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.BranchManagerName && !!errors.BranchManagerName}
                                                            />
                                                            <ErrorMessage name="BranchManagerName" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Branch Opening Date <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="date"
                                                                name="BranchOpeningDate"
                                                                value={values.BranchOpeningDate}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.BranchOpeningDate && !!errors.BranchOpeningDate}
                                                            />
                                                            <ErrorMessage name="BranchOpeningDate" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Cash Limit (₹) <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="number"
                                                                name="CashLimit"
                                                                placeholder="500000"
                                                                value={values.CashLimit}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.CashLimit && !!errors.CashLimit}
                                                            />
                                                            <ErrorMessage name="CashLimit" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Opening Cash Balance (₹) <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="number"
                                                                name="OpeningCashBalance"
                                                                placeholder="0"
                                                                value={values.OpeningCashBalance}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.OpeningCashBalance && !!errors.OpeningCashBalance}
                                                            />
                                                            <ErrorMessage name="OpeningCashBalance" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="6">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Branch Address <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="text"
                                                                name="BranchAddress"
                                                                placeholder="Full branch address"
                                                                value={values.BranchAddress}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.BranchAddress && !!errors.BranchAddress}
                                                            />
                                                            <ErrorMessage name="BranchAddress" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="3">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                State <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="select"
                                                                name="F_StateMaster"
                                                                value={values.F_StateMaster}
                                                                onChange={(e) => handleStateChange(e, handleChange, setFieldValue)}
                                                                onBlur={handleBlur}
                                                                invalid={touched.F_StateMaster && !!errors.F_StateMaster}
                                                            >
                                                                <option value="">-- Select State --</option>
                                                                {dropdowns.states.map((stateOption) => (
                                                                    <option key={stateOption?.Id} value={stateOption?.Id ?? ""}>
                                                                        {stateOption?.Name || `State ${stateOption?.Id ?? ""}`}
                                                                    </option>
                                                                ))}
                                                            </Input>
                                                            <ErrorMessage name="F_StateMaster" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="3">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                City <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="select"
                                                                name="F_CityMaster"
                                                                value={values.F_CityMaster}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.F_CityMaster && !!errors.F_CityMaster}
                                                                disabled={!values.F_StateMaster}
                                                            >
                                                                <option value="">Select City</option>
                                                                {dropdowns.cities.map((cityOption) => (
                                                                    <option key={cityOption?.Id} value={cityOption?.Id ?? ""}>
                                                                        {cityOption?.Name || `City ${cityOption?.Id ?? ""}`}
                                                                    </option>
                                                                ))}
                                                            </Input>
                                                            <ErrorMessage name="F_CityMaster" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Contact Number <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="text"
                                                                name="ContactNumber"
                                                                placeholder="+91-XXXXXXXXXX"
                                                                value={values.ContactNumber}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.ContactNumber && !!errors.ContactNumber}
                                                            />
                                                            <ErrorMessage name="ContactNumber" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>
                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Email <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="email"
                                                                name="Email"
                                                                placeholder="branch@abcfinance.com"
                                                                value={values.Email}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.Email && !!errors.Email}
                                                            />
                                                            <ErrorMessage name="Email" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                    <Col md="4">
                                                        <FormGroup className="mb-0">
                                                            <Label>
                                                                Status <span className="text-danger">*</span>
                                                            </Label>
                                                            <Input
                                                                type="select"
                                                                name="Status"
                                                                value={values.Status}
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                                invalid={touched.Status && !!errors.Status}
                                                            >
                                                                <option value="Active">Active</option>
                                                                <option value="Inactive">Inactive</option>
                                                            </Input>
                                                            <ErrorMessage name="Status" component="div" className="text-danger small mt-1" />
                                                        </FormGroup>
                                                    </Col>

                                                </Row>
                                            </fieldset>
                                        </CardBody>
                                        <CardFooter className="d-flex align-items-center gap-2 py-2">
                                            <Btn color="primary" type="submit" disabled={isSubmitting || !boState.isEditingOpen}>
                                                <i className="fa fa-plus me-1"></i> {isEditMode ? "Update Branch Office" : "Create Branch"}
                                            </Btn>
                                        </CardFooter>
                                    </Card>
                                </Form>
                            )}
                        </Formik>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default BranchOfficeCreation;
